# Deploy

Static site.

## Local

```bash
python -m http.server 8000
```

## Host

Upload all files.

Entry point:

`index.html`
