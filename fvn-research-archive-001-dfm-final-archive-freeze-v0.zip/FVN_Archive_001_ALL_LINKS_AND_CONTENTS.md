# FVN Research Archive 001 - All Links and Contents

Generated: 2026-07-07T19:49:04.556827+00:00

## Core repository

- Latest full repository ZIP: `/mnt/data/fvn-research-archive-001-dfm-final-archive-freeze-v0.zip`

## PDF release kit

- `00_FVN_Archive_001_Library_Index.pdf`
- `01_Executive_Brief.pdf`
- `02_Research_Note_Methodology.pdf`
- `03_Reproducibility_Runbook.pdf`
- `04_Audit_Controls_Report.pdf`
- `05_Publication_And_Storage_Guide.pdf`
- `06_Final_Archive_Freeze_Record.pdf`
- `FVN_Research_Archive_001_Complete_PDF_Book.pdf`

## Library interpretation

Archive 001 v0 is a complete library-grade research infrastructure and audit framework. It is not yet a live-data empirical alpha claim. For empirical publication, configure live-data readiness, run the live pipeline, regenerate reports, and freeze a new evidence-backed release.

## Recommended public presentation surfaces

1. PUBLICATION_README.md
2. Executive Brief PDF
3. Research Note Methodology PDF
4. Audit Controls Report PDF
5. Reproducibility Runbook PDF
6. Sanitized publication package ZIP
7. Final archive freeze metadata
